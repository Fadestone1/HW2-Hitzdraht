K = .6;
tau =  .3;

%X = [tau, K];
close all;
Ds = [.5e-3, .8e-3, 1e-3];
yEff = [[0.00000001], [Ds/2*1.3]];
yEffp = yEff * utau(tau) / nu;
uMessp = [[0]; [sqrt(squeeze(sensor_means(pos, speed, angle, :)) * 2 / rho)] / utau(tau)]';

formula = @(yp, K, tau) 2 * (1+pp(tau)*yp) / ( 1 + sqrt(1 + 4*(K*yp)^2 * (1+pp(tau)*yp) * (1 - exp(-yp * sqrt(1+pp(tau)*yp) / Ap))^2));
int = @(yp, X) ode45(@(yp, y) formula(yp, X(2), X(1)), [[0],sort(yEffp)], 0);

hold on
scatter(yEffp, uMessp);
ode45(@(yp, y) formula(yp, X(2), X(1)), [[0],sort(yEffp)], 1)